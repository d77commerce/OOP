﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
  public  interface IAge
    {
        public int Age { get;}
    }
}
