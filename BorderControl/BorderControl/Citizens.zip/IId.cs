﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    interface IId
    {
        public string Id { get;}
    }
}
