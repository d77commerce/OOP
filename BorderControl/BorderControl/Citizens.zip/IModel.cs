﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
  public  interface IModel
    {
        public string Model { get; }
    }
}
