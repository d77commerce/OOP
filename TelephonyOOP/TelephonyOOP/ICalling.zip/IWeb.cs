﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TelephonyOOP
{
  public  interface IWeb
    {
        public string Browsing (string input);
    }
}
