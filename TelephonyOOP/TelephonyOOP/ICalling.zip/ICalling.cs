﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TelephonyOOP
{
   public interface ICalling
    {
        public string Calling(string number);
    }
}
