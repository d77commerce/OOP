﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.food
{
    public class Meat : Food
    {
        public Meat(int qty) : base(qty)
        {
        }
    }
}
