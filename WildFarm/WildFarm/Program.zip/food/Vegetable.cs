﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.food
{
    public class Vegetable : Food
    {
        public Vegetable(int qty) : base(qty)
        {
        }
    }
}
