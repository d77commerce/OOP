﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.food
{
    public class Seeds : Food
    {
        public Seeds(int qty) : base(qty)
        {
        }
    }
}
