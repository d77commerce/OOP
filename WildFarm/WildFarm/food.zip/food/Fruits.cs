﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.food
{
    public class Fruits : Food
    {
        public Fruits(int qty) : base(qty)
        {
        }
    }
}
