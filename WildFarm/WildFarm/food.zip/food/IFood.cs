﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.food
{
  public  interface IFood
    {
        public int Qty { get; set; }
    }
}
